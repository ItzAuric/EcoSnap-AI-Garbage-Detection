import React, { useState, useRef } from 'react';
import { Camera, Upload, X, Check, Loader2, AlertTriangle, Leaf } from 'lucide-react';
import { analyzeWasteImage } from '../services/geminiService';
import { ScanResult, WasteCategory } from '../types';

interface ScannerProps {
  onScanComplete: (result: ScanResult) => void;
}

export const Scanner: React.FC<ScannerProps> = ({ onScanComplete }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ScanResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Create preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(file);

    // Reset previous states
    setError(null);
    setResult(null);
    setIsAnalyzing(true);

    try {
      const data = await analyzeWasteImage(file);
      setResult(data);
    } catch (err) {
      setError("Failed to analyze image. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setPreview(null);
    setResult(null);
    setError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleConfirm = () => {
    if (result) {
      onScanComplete(result);
      handleReset();
    }
  };

  const getCategoryColor = (category: WasteCategory) => {
    switch (category) {
      case WasteCategory.Recyclable: return 'bg-blue-100 text-blue-800 border-blue-200';
      case WasteCategory.NonRecyclable: return 'bg-gray-100 text-gray-800 border-gray-200';
      case WasteCategory.Wet: return 'bg-green-100 text-green-800 border-green-200';
      case WasteCategory.Hazardous: return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="h-full flex flex-col pb-24 animate-fade-in">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Identify Waste</h2>

      {!preview ? (
        <div className="flex-1 flex flex-col items-center justify-center space-y-6">
          <div className="w-full max-w-sm aspect-[4/5] bg-gray-50 border-2 border-dashed border-gray-300 rounded-3xl flex flex-col items-center justify-center p-8 text-center hover:bg-gray-100 transition-colors">
            <div className="bg-emerald-100 p-6 rounded-full text-emerald-600 mb-4">
              <Camera size={48} />
            </div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Snap a Picture</h3>
            <p className="text-gray-500 mb-6 text-sm">Position the waste item clearly in the frame</p>
            
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="bg-emerald-500 text-white px-8 py-3 rounded-full font-semibold shadow-lg hover:bg-emerald-600 transition-all flex items-center"
            >
              <Camera size={20} className="mr-2" />
              Take Photo
            </button>
            
            <p className="mt-4 text-xs text-gray-400">or upload from gallery</p>
          </div>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept="image/*" 
            capture="environment"
            className="hidden" 
          />
        </div>
      ) : (
        <div className="flex-1 flex flex-col relative">
          <div className="relative rounded-3xl overflow-hidden shadow-lg aspect-[4/3] mb-6">
            <img src={preview} alt="Preview" className="w-full h-full object-cover" />
            <button 
              onClick={handleReset}
              className="absolute top-4 right-4 bg-black/50 text-white p-2 rounded-full backdrop-blur-sm hover:bg-black/70"
            >
              <X size={20} />
            </button>
          </div>

          {isAnalyzing && (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
              <Loader2 size={48} className="text-emerald-500 animate-spin mb-4" />
              <h3 className="text-lg font-semibold text-gray-800">Analyzing Image...</h3>
              <p className="text-gray-500">Our AI is identifying the waste type.</p>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-100 p-4 rounded-xl text-red-800 flex items-start">
              <AlertTriangle className="mr-3 flex-shrink-0 mt-0.5" size={20} />
              <p>{error}</p>
            </div>
          )}

          {result && (
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6 animate-slide-up">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold border mb-2 ${getCategoryColor(result.category)}`}>
                    {result.category}
                  </span>
                  <h3 className="text-2xl font-bold text-gray-800">{result.wasteType}</h3>
                </div>
                <div className="bg-emerald-50 p-2 rounded-full">
                  <Leaf className="text-emerald-500" size={24} />
                </div>
              </div>
              
              <div className="space-y-4 mb-6">
                <div>
                  <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-1">Disposal Guide</h4>
                  <p className="text-gray-700 bg-gray-50 p-3 rounded-lg text-sm leading-relaxed border border-gray-100">
                    {result.disposalTip}
                  </p>
                </div>
                
                {result.isHazardous && (
                  <div className="flex items-center text-amber-600 bg-amber-50 p-3 rounded-lg text-sm border border-amber-100">
                    <AlertTriangle size={16} className="mr-2" />
                    Handle with care. Hazardous material.
                  </div>
                )}
              </div>

              <button 
                onClick={handleConfirm}
                className="w-full bg-emerald-500 text-white py-4 rounded-xl font-bold shadow-lg hover:bg-emerald-600 transition-colors flex items-center justify-center"
              >
                <Check size={20} className="mr-2" />
                Confirm & Recycle
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};