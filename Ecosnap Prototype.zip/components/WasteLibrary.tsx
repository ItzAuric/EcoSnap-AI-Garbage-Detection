import React, { useState } from 'react';
import { Search, Info } from 'lucide-react';
import { WasteCategory, WasteItem } from '../types';

const MOCK_WASTE_ITEMS: WasteItem[] = [
  { id: '1', name: 'Plastic Bottle', category: WasteCategory.Recyclable, description: 'PET plastic bottles.', disposalTip: 'Rinse, crush, and place in blue bin.' },
  { id: '2', name: 'Banana Peel', category: WasteCategory.Wet, description: 'Organic fruit waste.', disposalTip: 'Compost bin or green waste bin.' },
  { id: '3', name: 'Battery (AA)', category: WasteCategory.Hazardous, description: 'Alkaline battery.', disposalTip: 'Take to e-waste collection center. Do not bin.' },
  { id: '4', name: 'Pizza Box (Greasy)', category: WasteCategory.NonRecyclable, description: 'Cardboard contaminated with oil.', disposalTip: 'General waste bin or compost if allowed.' },
  { id: '5', name: 'Newspaper', category: WasteCategory.Recyclable, description: 'Paper waste.', disposalTip: 'Keep dry and place in paper recycling.' },
  { id: '6', name: 'Glass Jar', category: WasteCategory.Recyclable, description: 'Food glass container.', disposalTip: 'Rinse and remove lid. Recycle glass bin.' },
  { id: '7', name: 'Chip Bag', category: WasteCategory.NonRecyclable, description: 'Metallized plastic film.', disposalTip: 'General waste bin.' },
  { id: '8', name: 'Egg Shells', category: WasteCategory.Wet, description: 'Organic waste.', disposalTip: 'Compost.' },
];

export const WasteLibrary: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<WasteCategory | 'All'>('All');

  const filteredItems = MOCK_WASTE_ITEMS.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="pb-24 animate-fade-in">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Waste Library</h2>
      
      {/* Search Bar */}
      <div className="relative mb-6">
        <input
          type="text"
          placeholder="Search items..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all shadow-sm"
        />
        <Search className="absolute left-3 top-3.5 text-gray-400" size={20} />
      </div>

      {/* Categories */}
      <div className="flex overflow-x-auto space-x-2 mb-6 pb-2 no-scrollbar">
        {['All', ...Object.values(WasteCategory)].map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat as WasteCategory | 'All')}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              selectedCategory === cat
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="space-y-4">
        {filteredItems.map(item => (
          <div key={item.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-start hover:shadow-md transition-shadow">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center text-xl mr-4 flex-shrink-0 ${
              item.category === WasteCategory.Recyclable ? 'bg-blue-100' :
              item.category === WasteCategory.Wet ? 'bg-green-100' :
              item.category === WasteCategory.Hazardous ? 'bg-red-100' :
              'bg-gray-100'
            }`}>
              {item.category === WasteCategory.Recyclable ? '♻️' :
               item.category === WasteCategory.Wet ? '🌱' :
               item.category === WasteCategory.Hazardous ? '☣️' : '🗑️'}
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <h3 className="font-semibold text-gray-800">{item.name}</h3>
                <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-md ${
                  item.category === WasteCategory.Recyclable ? 'text-blue-600 bg-blue-50' :
                  item.category === WasteCategory.Wet ? 'text-green-600 bg-green-50' :
                  item.category === WasteCategory.Hazardous ? 'text-red-600 bg-red-50' :
                  'text-gray-600 bg-gray-50'
                }`}>
                  {item.category}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1">{item.description}</p>
              <div className="mt-3 flex items-start text-xs text-gray-600 bg-gray-50 p-2 rounded-lg">
                <Info size={14} className="mr-1.5 flex-shrink-0 mt-0.5 text-emerald-500" />
                {item.disposalTip}
              </div>
            </div>
          </div>
        ))}

        {filteredItems.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <p>No items found.</p>
          </div>
        )}
      </div>
    </div>
  );
};