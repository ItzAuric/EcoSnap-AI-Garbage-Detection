import React from 'react';
import { Flame, Droplets, Zap, ArrowRight, Recycle, Truck, ChevronRight } from 'lucide-react';
import { UserStats, Tab, User } from '../types';

interface DashboardProps {
  userStats: UserStats;
  currentUser: User | null;
  onScanClick: () => void;
  onTrackClick?: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ userStats, currentUser, onScanClick, onTrackClick }) => {
  return (
    <div className="space-y-6 pb-24 animate-fade-in">
      {/* Header */}
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Hello, {currentUser?.name.split(' ')[0] || 'Eco Warrior'} 👋</h1>
          <p className="text-gray-500 text-sm">Let's make the world cleaner.</p>
        </div>
        <div className="bg-white p-2 rounded-full shadow-sm border border-emerald-100">
           <img 
             src={`https://ui-avatars.com/api/?name=${currentUser?.name || 'User'}&background=10b981&color=fff`}
             alt="Profile" 
             className="w-10 h-10 rounded-full" 
           />
        </div>
      </header>

      {/* Main Stats Card */}
      <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-10 rounded-full -mr-10 -mt-10"></div>
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-emerald-100 text-sm font-medium">Total Eco Points</p>
              <h2 className="text-4xl font-bold mt-1">{userStats.points.toLocaleString()}</h2>
            </div>
            <div className="flex items-center bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full">
              <Flame size={16} className="text-orange-300 mr-1" />
              <span className="text-sm font-semibold">{userStats.streak} Day Streak</span>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-6">
            <div className="bg-white/10 p-3 rounded-xl">
              <p className="text-emerald-100 text-xs">CO2 Saved</p>
              <p className="font-semibold text-lg">{userStats.co2Saved}kg</p>
            </div>
            <div className="bg-white/10 p-3 rounded-xl">
              <p className="text-emerald-100 text-xs">Items Recycled</p>
              <p className="font-semibold text-lg">{userStats.itemsRecycled}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Live Tracker Widget - New Addition */}
      <div className="bg-white rounded-2xl p-1 shadow-sm border border-emerald-100 overflow-hidden">
        <div 
          onClick={onTrackClick}
          className="bg-emerald-50/50 p-4 rounded-xl flex items-center justify-between cursor-pointer hover:bg-emerald-50 transition-colors group"
        >
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 mr-3 relative">
              <Truck size={20} />
              <span className="absolute top-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full animate-pulse"></span>
            </div>
            <div>
              <h3 className="font-semibold text-gray-800 text-sm">Collection Truck Nearby</h3>
              <p className="text-xs text-emerald-600 font-medium">Arriving in 12 mins • Sector 4</p>
            </div>
          </div>
          <ChevronRight size={20} className="text-gray-400 group-hover:text-emerald-500 transition-colors" />
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-3">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={onScanClick}
            className="bg-white p-4 rounded-xl shadow-sm border border-emerald-100 hover:shadow-md transition-shadow flex flex-col items-center justify-center text-center group"
          >
            <div className="bg-emerald-100 p-3 rounded-full text-emerald-600 mb-3 group-hover:scale-110 transition-transform">
              <Recycle size={24} />
            </div>
            <span className="font-medium text-gray-700">Scan Waste</span>
          </button>
          
          <div className="bg-white p-4 rounded-xl shadow-sm border border-emerald-100 hover:shadow-md transition-shadow flex flex-col items-center justify-center text-center cursor-pointer">
             <div className="bg-blue-100 p-3 rounded-full text-blue-600 mb-3">
              <Droplets size={24} />
            </div>
            <span className="font-medium text-gray-700">Log Water</span>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div>
        <div className="flex justify-between items-end mb-3">
          <h3 className="text-lg font-semibold text-gray-800">Recent Activity</h3>
          <button className="text-emerald-600 text-sm font-medium flex items-center">
            View All <ArrowRight size={14} className="ml-1" />
          </button>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          {[1, 2, 3].map((i) => (
            <div key={i} className="p-4 border-b border-gray-50 last:border-0 flex items-center">
              <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-xl mr-3">
                {i === 1 ? '🥤' : i === 2 ? '📰' : '🍌'}
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-gray-800">{i === 1 ? 'Plastic Cup' : i === 2 ? 'Newspaper' : 'Banana Peel'}</h4>
                <p className="text-xs text-gray-500">{i === 1 ? 'Recycled' : i === 2 ? 'Recycled' : 'Composted'} • 2h ago</p>
              </div>
              <span className="text-emerald-600 font-bold text-sm">+{(4 - i) * 10} pts</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};