import React from 'react';
import { ArrowLeft, Truck, MapPin, Phone, Clock, Navigation as NavIcon } from 'lucide-react';

interface TrackerProps {
  onBack: () => void;
}

export const Tracker: React.FC<TrackerProps> = ({ onBack }) => {
  return (
    <div className="h-full flex flex-col bg-white animate-fade-in relative z-50">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 p-4 z-10 flex items-center bg-gradient-to-b from-white/80 to-transparent backdrop-blur-[2px]">
        <button 
          onClick={onBack}
          className="bg-white p-2.5 rounded-full shadow-md text-gray-700 hover:bg-gray-50 active:scale-95 transition-all"
        >
          <ArrowLeft size={20} />
        </button>
        <h1 className="ml-4 text-lg font-bold text-gray-800 bg-white/90 px-3 py-1 rounded-full shadow-sm backdrop-blur-sm">
          Tracking Vehicle
        </h1>
      </div>

      {/* Map Area (Simulated) */}
      <div className="flex-1 bg-gray-100 relative overflow-hidden group">
        {/* Map Pattern / Background */}
        <div className="absolute inset-0 opacity-10" 
             style={{
               backgroundImage: 'radial-gradient(#94a3b8 1.5px, transparent 1.5px), radial-gradient(#94a3b8 1.5px, transparent 1.5px)',
               backgroundSize: '24px 24px',
               backgroundPosition: '0 0, 12px 12px'
             }}>
        </div>
        
        {/* Simulated Roads */}
        <div className="absolute top-1/2 left-0 right-0 h-24 -mt-12 bg-gray-200 rotate-12 transform scale-125 border-y-4 border-white"></div>
        <div className="absolute top-0 bottom-0 left-1/2 w-16 -ml-8 bg-gray-200 rotate-12 transform scale-125 border-x-4 border-white"></div>

        {/* User Location Marker */}
        <div className="absolute top-1/2 left-1/2 -ml-3 -mt-3 transform translate-x-12 translate-y-12">
            <div className="w-6 h-6 bg-blue-500 rounded-full border-4 border-white shadow-lg animate-pulse"></div>
            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-white px-2 py-0.5 rounded text-[10px] font-bold shadow text-gray-700 whitespace-nowrap">
                You
            </div>
        </div>

        {/* Truck Marker (Animated) */}
        <div className="absolute top-1/2 left-1/2 transition-all duration-1000 ease-in-out">
            {/* Movement Simulation */}
            <div className="relative -ml-6 -mt-6 animate-[moveTruck_10s_linear_infinite]">
                 <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center text-white shadow-xl z-10 relative ring-4 ring-emerald-200">
                    <Truck size={24} />
                 </div>
                 {/* Ripple Effect */}
                 <div className="absolute inset-0 bg-emerald-500 rounded-full animate-ping opacity-20"></div>
                 
                 {/* Tooltip */}
                 <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-white px-3 py-1 rounded-lg shadow-md whitespace-nowrap z-20">
                    <span className="text-xs font-bold text-gray-800">12 min away</span>
                    <div className="absolute bottom-[-6px] left-1/2 -translate-x-1/2 w-3 h-3 bg-white rotate-45"></div>
                 </div>
            </div>
        </div>
        
        <style>{`
            @keyframes moveTruck {
                0% { transform: translate(-100px, -50px); }
                50% { transform: translate(-20px, 0px); }
                100% { transform: translate(60px, 40px); }
            }
        `}</style>
      </div>

      {/* Bottom Sheet Info Panel */}
      <div className="bg-white rounded-t-3xl shadow-[0_-5px_20px_-5px_rgba(0,0,0,0.1)] -mt-6 relative z-20 pb-safe">
        <div className="w-12 h-1.5 bg-gray-200 rounded-full mx-auto mt-3 mb-6"></div>
        
        <div className="px-6 pb-8">
            {/* Time & Status */}
            <div className="flex justify-between items-end mb-6">
                <div>
                    <p className="text-sm text-gray-500 font-medium mb-1">Arriving By</p>
                    <h2 className="text-3xl font-bold text-gray-800">08:45 AM</h2>
                </div>
                <div className="text-right">
                    <span className="inline-flex items-center text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full text-xs font-bold">
                        <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2 animate-pulse"></span>
                        On Route
                    </span>
                </div>
            </div>

            {/* Driver Card */}
            <div className="flex items-center bg-gray-50 p-4 rounded-xl mb-6 border border-gray-100">
                <img src="https://picsum.photos/id/64/60/60" alt="Driver" className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm" />
                <div className="ml-4 flex-1">
                    <h3 className="font-bold text-gray-800">Rajesh Kumar</h3>
                    <p className="text-xs text-gray-500">Vehicle: MH-14-GT-4022</p>
                </div>
                <button className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-emerald-500 shadow-sm border border-gray-100 hover:bg-emerald-50">
                    <Phone size={20} />
                </button>
            </div>

            {/* Timeline */}
            <div className="space-y-0 relative">
                {/* Connecting Line */}
                <div className="absolute left-3 top-4 bottom-4 w-0.5 bg-gray-200"></div>

                {/* Steps */}
                {[
                    { title: 'Central Depot', time: '08:00 AM', status: 'completed' },
                    { title: 'Sector 4 Market', time: '08:20 AM', status: 'completed' },
                    { title: 'Your Location', time: 'Est. 08:45 AM', status: 'current' },
                    { title: 'Recycling Plant', time: '09:30 AM', status: 'upcoming' },
                ].map((step, idx) => (
                    <div key={idx} className="flex items-start relative mb-6 last:mb-0">
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center z-10 bg-white ${
                            step.status === 'completed' ? 'border-emerald-500 text-emerald-500' :
                            step.status === 'current' ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
                        }`}>
                            {step.status === 'completed' && <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full" />}
                            {step.status === 'current' && <div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-pulse" />}
                        </div>
                        <div className="ml-4 flex-1">
                            <p className={`text-sm font-semibold ${step.status === 'upcoming' ? 'text-gray-400' : 'text-gray-800'}`}>
                                {step.title}
                            </p>
                            <p className="text-xs text-gray-500">{step.time}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};