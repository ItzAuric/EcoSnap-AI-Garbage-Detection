import { GoogleGenAI, Type } from "@google/genai";
import { ScanResult, WasteCategory } from "../types";

// Helper to convert file to base64
const fileToGenerativePart = async (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      // Remove the data URL prefix (e.g., "data:image/jpeg;base64,")
      const base64Data = base64String.split(',')[1];
      resolve(base64Data);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export const analyzeWasteImage = async (file: File): Promise<ScanResult> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      // Return a mock result if no API key is present (for MVP testing without key)
      console.warn("No API Key found. Returning mock data.");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve({
            wasteType: "Plastic Bottle (Mock)",
            category: WasteCategory.Recyclable,
            confidence: 0.95,
            disposalTip: "Rinse and place in the blue recycling bin.",
            isHazardous: false
          });
        }, 1500);
      });
    }

    const ai = new GoogleGenAI({ apiKey });
    const base64Data = await fileToGenerativePart(file);

    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash-exp', // Using a flash model for speed/vision
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: file.type,
            },
          },
          {
            text: `Analyze this image and identify the primary waste item. 
            Return a JSON object with the following fields:
            - wasteType: string (Name of the item)
            - category: string (One of: Recyclable, Non-Recyclable, Wet, Dry, Hazardous)
            - confidence: number (0 to 1)
            - disposalTip: string (Short advice on how to dispose of it properly)
            - isHazardous: boolean
            `
          },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            wasteType: { type: Type.STRING },
            category: { type: Type.STRING },
            confidence: { type: Type.NUMBER },
            disposalTip: { type: Type.STRING },
            isHazardous: { type: Type.BOOLEAN },
          },
          required: ["wasteType", "category", "confidence", "disposalTip", "isHazardous"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    const result = JSON.parse(text);
    
    // Map string category to enum if needed, or just cast
    return {
      wasteType: result.wasteType,
      category: result.category as WasteCategory,
      confidence: result.confidence,
      disposalTip: result.disposalTip,
      isHazardous: result.isHazardous
    };

  } catch (error) {
    console.error("Error analyzing image:", error);
    throw error;
  }
};